<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize query and parameters
$query = "";
$params = array(); 

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    echo "Please select Buyer or Seller name only"; // Handle "ALL" partyType if needed
} elseif ($partyType === "BUYER") {
    // Query for Buyer
    $query = "SELECT P_GATEPASS [ASN_NO], P_PONO [PO NO], P_CONTRACT_NO [CONTRACT NO], P_SELLER_NAME [SELLER NAME],
              P_ITEM [MATERIAL NAME], SUM(P_ITEM_QUANTITY) [QTY_MT], P_INVOICE_NO [INVOICE NO], P_INVOICE_AMT [AMOUNT],
              P_ETA_GATEIN [GATE IN], P_VESSEL_STATUS [VESSEL_STATUS], P_PAYMENT_REMARK [PAYMENT_STATUS],
              P_DOCSETA_REMARK [DOCS_RECV/SENT] FROM PURCHASE 
              WHERE P_BUYER_NAME = ? AND ISNULL(P_PAYMENT_STATUS, 0) <> 1 
              GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_ITEM, P_INVOICE_NO, P_INVOICE_AMT,
                       P_CURRENCY, P_ETA_GATEIN, P_VESSEL_STATUS, P_PAYMENT_REMARK, P_DOCSETA_REMARK";

    // Params for Buyer filter (add FROM and TO date if needed)
    $params = array($partyName);
} elseif ($partyType === "SELLER") {
    // Query for Seller (add seller name logic here)
    $query = "SELECT P_GATEPASS [ASN_NO], P_PONO [PO NO], P_CONTRACT_NO [CONTRACT NO], P_SELLER_NAME [SELLER NAME],
              P_ITEM [MATERIAL NAME], SUM(P_ITEM_QUANTITY) [QTY_MT], P_INVOICE_NO [INVOICE NO], P_INVOICE_AMT [AMOUNT],
              P_ETA_GATEIN [GATE IN], P_VESSEL_STATUS [VESSEL_STATUS], P_PAYMENT_REMARK [PAYMENT_STATUS],
              P_DOCSETA_REMARK [DOCS_RECV/SENT] FROM PURCHASE 
              WHERE P_SELLER_NAME = ? AND ISNULL(P_PAYMENT_STATUS, 0) <> 1 
              GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_ITEM, P_INVOICE_NO, P_INVOICE_AMT,
                       P_CURRENCY, P_ETA_GATEIN, P_VESSEL_STATUS, P_PAYMENT_REMARK, P_DOCSETA_REMARK";
    $params = array($partyName); // Use the correct parameter for Seller
} else {
    echo "Invalid party type selected.";
    exit;
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>ASN No</th><th>PO No</th><th>CONTRACT NO</th>
                    <th>Seller Name</th><th>MATERIAL NAME</th><th>QTY_MT</th><th>INVOICE NO</th>
                    <th>AMOUNT</th><th>GATE IN</th><th>VESSEL STATUS</th>
                    <th>PAYMENT STATUS</th><th>DOCS RECV/SENT</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            $sellerName = isset($row['SELLER NAME']) ? htmlspecialchars($row['SELLER NAME']) : 'N/A';
            $materialName = isset($row['MATERIAL NAME']) ? htmlspecialchars($row['MATERIAL NAME']) : 'N/A';
            $invoiceNo = isset($row['INVOICE NO']) ? htmlspecialchars($row['INVOICE NO']) : 'N/A';
            $amount = isset($row['AMOUNT']) ? htmlspecialchars($row['AMOUNT']) : 'N/A';
            $gateIn = isset($row['GATE IN']) ? htmlspecialchars($row['GATE IN']) : 'N/A';
            $vesselStatus = isset($row['VESSEL_STATUS']) ? htmlspecialchars($row['VESSEL_STATUS']) : 'N/A';
            $paymentStatus = isset($row['PAYMENT_STATUS']) ? htmlspecialchars($row['PAYMENT_STATUS']) : 'N/A';
            $docsRecvSent = isset($row['DOCS_RECV/SENT']) ? htmlspecialchars($row['DOCS_RECV/SENT']) : 'N/A';

            // Display the row data
            echo "<tr>
                    <td>" . htmlspecialchars($row['ASN_NO']) . "</td>
                    <td>" . htmlspecialchars($row['PO NO']) . "</td>
                    <td>" . htmlspecialchars($row['CONTRACT NO']) . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $materialName . "</td>
                    <td>" . htmlspecialchars($row['QTY_MT']) . "</td>
                    <td>" . $invoiceNo . "</td>
                    <td>" . $amount . "</td>
                    <td>" . $gateIn . "</td>
                    <td>" . $vesselStatus . "</td>
                    <td>" . $paymentStatus . "</td>
                    <td>" . $docsRecvSent . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));

        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
