<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT PO_NO,PO_DATE,PO_SALES_CONT_NO [CONTRACT_NO],PO_CONTRACT_DATE [CONTRACT_DATE],PO_SELLER_NAME [SELLER_NAME],
                 PO_BUYER_NAME [BUYER_NAME],PO_ITEM_DESC [MATERIAL],PO_RATE [PRICE],PO_QUANTITY [PO_QTY],
                 isnull(SUM(P_ITEM_QUANTITY),0) [SHIPPED_QTY],(PO_QUANTITY-isnull(SUM(P_ITEM_QUANTITY),0)) BALANCE_QTY,
				 DATEDIFF(DAY, PO_SHIPMENT_DATE, GETDATE()) [DAYS PENDING SHIPMENT DATE] 
                 FROM PO_HDR LEFT JOIN PURCHASE ON PO_NO = P_PONO WHERE ISNULL(P_STATUS,0)<>9 and isnull(P_ASN_STATUS,0)<>1 ";

$params = array(); // Prepare an array to store query parameters

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= " GROUP BY PO_NO,PO_DATE,PO_SALES_CONT_NO,PO_CONTRACT_DATE,PO_SELLER_NAME,PO_BUYER_NAME,PO_ITEM_DESC,PO_RATE,
				 PO_QUANTITY,PO_SHIPMENT_DATE  having (PO_QUANTITY-isnull(SUM(P_ITEM_QUANTITY),0))>0 order by PO_NO";
    $params = array($fromDate, $toDate); // Adding filter for ALL case
} elseif ($partyType === "BUYER") {
    $query .= " AND PO_DATE BETWEEN ? AND ? AND PO_BUYER_NAME = ?
                 GROUP BY PO_NO,PO_DATE,PO_SALES_CONT_NO,PO_CONTRACT_DATE,PO_SELLER_NAME,PO_BUYER_NAME,
                 PO_ITEM_DESC,PO_RATE,PO_QUANTITY,PO_SHIPMENT_DATE  having (PO_QUANTITY-isnull(SUM(P_ITEM_QUANTITY),0))>0 order by PO_NO";
    $params = array($fromDate, $toDate, $partyName);
} elseif ($partyType === "SELLER") {
    $query .= " AND PO_DATE BETWEEN ? AND ? AND PO_BUYER_NAME = ?
                GROUP BY PO_NO,PO_DATE,PO_SALES_CONT_NO,PO_CONTRACT_DATE,PO_SELLER_NAME,PO_BUYER_NAME,PO_ITEM_DESC,PO_RATE,
				 PO_QUANTITY,PO_SHIPMENT_DATE  having (PO_QUANTITY-isnull(SUM(P_ITEM_QUANTITY),0))>0 order by PO_NO";
    $params = array($fromDate, $toDate, $partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>PO NO</th><th>PO_DATE</th><th>CONTRACT_NO</th><th>CONTRACT_DATE</th>
                    <th>Seller Name</th><th>BUYER NAME</th><th>MATERIAL</th><thPRICE</th>
                    <th>PO_QTY</th><th>SHIPPED_QTY</th><th>BALANCE_QTYT</th><th>BALANCE_QTY</th>
                    <th>DAYS PENDING SHIPMENT DATE</th>  
                </tr>";

        // Loop through the results and display them in the table
        do {

            $PO_DATE = $row['PO_DATE'] ? $row['PO_DATE']->format('Y-m-d') : 'N/A';
            $CONTRACT_DATE = $row['CONTRACT_DATE'] ? $row['PO_DATCONTRACT_DATEE']->format('Y-m-d') : 'N/A';
            
            $sellerName = isset($row['SELLER_NAME']) ? htmlspecialchars($row['SELLER_NAME']) : 'N/A';
            $buyerName = isset($row['BUYER_NAME']) ? htmlspecialchars($row['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['PO_NO']) . "</td>
                    <td>" . $PO_DATE . "</td>
                    <td>" . htmlspecialchars($row['CONTRACT_NO']) . "</td>
                    <td>" . $CONTRACT_DATE . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['MATERIAL']) . "</td>
                    <td>" . htmlspecialchars($row['PRICE']) . "</td>
                    <td>" . htmlspecialchars($row['PO_QTY']) . "</td>
                    <td>" . htmlspecialchars($row['SHIPPED_QTY']) . "</td>
                    <td>" . htmlspecialchars($row['BALANCE_QTY']) . "</td>
                    <td>" . htmlspecialchars($row['DAYS PENDING SHIPMENT DATE']) . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));
        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
