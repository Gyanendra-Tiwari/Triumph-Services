<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT P_GATEPASS AS [ASN_NO], P_PONO AS [PO NO], P_CONTRACT_NO AS [CONTRACT NO], P_SELLER_NAME AS [SELLER NAME],
              P_BUYER_NAME AS [BUYER NAME], P_INVOICE_NO AS [INVOICE NO.], SUM(P_ITEM_QUANTITY) AS [QTY SHIPPED],
              P_INVOICE_AMT AS [INVOICE AMOUNT], P_ADVANCE_AMOUNT AS ADVANCE_ADJUSTED, P_FINAL_ADV_AMT AS FINAL_INVOICE_AMT,
              P_ETA_PORT_DATE AS [CNTR ETA (PORT)], P_ETA_ICD AS [CNTR ATA(ICD)],
              CASE WHEN P_ETA_PORT_DATE IS NOT NULL THEN DATEDIFF(DAY, P_ETA_PORT_DATE, GETDATE()) 
                   WHEN P_ETA_PORT_DATE IS NULL THEN DATEDIFF(DAY, P_ETA_ICD, GETDATE()) END AS DAYS_PENDING,
              P_PAYMENT_REMARK AS [PAYMENT_STATUS], P_DOCSETA_REMARK AS [DOCS_ETA] 
          FROM PURCHASE 
          WHERE ISNULL(p_payment_status, 0) = 0 AND ISNULL(p_status, 0) <> 9 ";

$params = array(); // Prepare an array to store query parameters

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= " 
                GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_BUYER_NAME, P_INVOICE_NO, P_INVOICE_AMT, 
                         P_ADVANCE_AMOUNT, P_FINAL_ADV_AMT, P_ETA_PORT_DATE, P_ETA_ICD, P_PAYMENT_REMARK, P_DOCSETA_REMARK 
                ORDER BY P_ETA_PORT_DATE, P_ETA_ICD DESC";
    $params = array($fromDate, $toDate); // Adding filter for ALL case
} elseif ($partyType === "BUYER") {
    $query .= " AND P_ETA_PORT_DATE BETWEEN ? AND ? AND P_BUYER_NAME = ? 
                GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_BUYER_NAME, P_INVOICE_NO, P_INVOICE_AMT, 
                         P_ADVANCE_AMOUNT, P_FINAL_ADV_AMT, P_ETA_PORT_DATE, P_ETA_ICD, P_PAYMENT_REMARK, P_DOCSETA_REMARK 
                ORDER BY P_ETA_PORT_DATE, P_ETA_ICD DESC";
    $params = array($fromDate, $toDate, $partyName);
} elseif ($partyType === "SELLER") {
    $query .= " AND P_ETA_PORT_DATE BETWEEN ? AND ? AND P_SELLER_NAME = ? 
                GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_BUYER_NAME, P_INVOICE_NO, P_INVOICE_AMT, 
                         P_ADVANCE_AMOUNT, P_FINAL_ADV_AMT, P_ETA_PORT_DATE, P_ETA_ICD, P_PAYMENT_REMARK, P_DOCSETA_REMARK 
                ORDER BY P_ETA_PORT_DATE, P_ETA_ICD DESC";
    $params = array($fromDate, $toDate, $partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>ASN No</th><th>PO No</th><th>CONTRACT_NO</th>
                    <th>Seller Name</th><th>BUYER NAME</th><th>INVOICE_NO</th>
                    <th>QTY_SHIPPED</th><th>INVOICE AMOUNT</th><th>ADVANCE_ADJUSTED</th>
                    <th>FINAL_INVOICE_AMT</th><th>CNTR ETA (PORT)</th><th>CNTR ATA(ICD)</th>
                    <th>DAYS_PENDING</th>
                    <th>PAYMENT_STATUS</th><th>DOCS_ETA</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            $P_ETA_PORT_DATE = $row['CNTR ETA (PORT)'] ? $row['CNTR ETA (PORT)']->format('Y-m-d') : 'N/A';
            $P_ETA_ICD = $row['CNTR ATA(ICD)'] ? $row['CNTR ATA(ICD)']->format('Y-m-d') : 'N/A';

            $sellerName = isset($row['SELLER NAME']) ? htmlspecialchars($row['SELLER NAME']) : 'N/A';
            $buyerName = isset($row['BUYER NAME']) ? htmlspecialchars($row['BUYER NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['ASN_NO']) . "</td>
                    <td>" . htmlspecialchars($row['PO NO']) . "</td>
                    <td>" . htmlspecialchars($row['CONTRACT NO']) . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['INVOICE NO.']) . "</td>
                    <td>" . htmlspecialchars($row['QTY SHIPPED']) . "</td>
                    <td>" . htmlspecialchars($row['INVOICE AMOUNT']) . "</td>
                    <td>" . htmlspecialchars($row['ADVANCE_ADJUSTED']) . "</td>
                    <td>" . htmlspecialchars($row['FINAL_INVOICE_AMT']) . "</td>
                    <td>" . $P_ETA_PORT_DATE . "</td>
                    <td>" . $P_ETA_ICD . "</td>
                    <td>" . htmlspecialchars($row['DAYS_PENDING']) . "</td>
                    <td>" . htmlspecialchars($row['PAYMENT_STATUS']) . "</td>
                    <td>" . htmlspecialchars($row['DOCS_ETA']) . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));

        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
