<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT PO_NO, PO_SALES_CONT_NO AS SALES_CONTRACT_NO, PO_CONTRACT_DATE AS CONTRACT_DATE,
                 PO_SELLER_NAME AS SELLER_NAME, PO_BUYER_NAME AS BUYER_NAME,
                 PO_ITEM_DESC AS MATERIAL, PO_RATE AS RATE, PO_QUANTITY AS QTY,
                 PO_ADVANCE_REMARK AS REMARKS, PO_ADV_AMT AS ADVANCE_AMOUNT
          FROM PO_HDR 
          WHERE PO_ADVANCE_FLAG = 1";

// Prepare parameters array
$params = array(); 

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= "";
    $params = array($fromDate, $toDate); // Adding filter for ALL case
} elseif ($partyType === "BUYER") {
    $query .= " AND (PO_CONTRACT_DATE BETWEEN ? AND ?) AND PO_BUYER_NAME = ?";
    $params = array($fromDate, $toDate, $partyName);
} elseif ($partyType === "SELLER") {
    $query .= " AND (PO_CONTRACT_DATE BETWEEN ? AND ?) AND PO_SELLER_NAME = ?";
    $params = array($fromDate, $toDate, $partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>PO_NO</th><th>SALES_CONTRACT_NO</th><th>CONTRACT_DATE</th>
                    <th>Seller Name</th><th>BUYER NAME</th><th>MATERIAL</th>
                    <th>RATE</th><th>QTY</th><th>REMARKS</th><th>ADVANCE AMOUNT</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            // Formatting the CONTRACT_DATE (if it's a DateTime object)
            $CONTRACT_DATE = isset($row['CONTRACT_DATE']) && $row['CONTRACT_DATE'] instanceof DateTime 
                             ? $row['CONTRACT_DATE']->format('Y-m-d') 
                             : 'N/A';

            // Sanitize output to prevent XSS
            $sellerName = isset($row['SELLER_NAME']) ? htmlspecialchars($row['SELLER_NAME']) : 'N/A';
            $buyerName = isset($row['BUYER_NAME']) ? htmlspecialchars($row['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['PO_NO']) . "</td>
                    <td>" . htmlspecialchars($row['SALES_CONTRACT_NO']) . "</td>
                    <td>" . $CONTRACT_DATE . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['MATERIAL']) . "</td>
                    <td>" . htmlspecialchars($row['RATE']) . "</td>
                    <td>" . htmlspecialchars($row['QTY']) . "</td>
                    <td>" . htmlspecialchars($row['REMARKS']) . "</td>
                    <td>" . htmlspecialchars($row['ADVANCE_AMOUNT']) . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));
        
        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
