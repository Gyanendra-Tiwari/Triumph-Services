<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name
$contractButton = isset($_POST['contract_button']) ? $_POST['contract_button'] : ''; // Check if contract_button is set
$contractNumber = isset($_POST['contract_number']) ? $_POST['contract_number'] : ''; // Get contract number

// Debugging: Output received dates and contract number for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";
echo "Contract Button: $contractButton <br>";
echo "Contract Number: $contractNumber <br>";

// Initialize base query with common fields
$query = "SELECT P_GATEPASS AS ASN_NO, P_PONO AS PO_NO, P_CONTRACT_NO AS CONTRACT_NO, 
                 P_INVOICE_NO AS INVOICE_NO, P_SELLER_NAME, P_BUYER_NAME, P_POD AS PORT_OF_DISCHARGE, 
                 P_ORIGIN_COUNTRY AS ORIGIN_COUNTRY, P_ASN_SAVE_DT AS ASN_DATE, 
                 SUM(P_ITEM_QUANTITY) AS NETWT 
          FROM PURCHASE 
          WHERE ISNULL(p_status, 0) <> 9 
            ";

// Modify the query based on the contract button and contract number
if ($contractButton === 'YES' && !empty($contractNumber)) {
    $query .= " AND P_CONTRACT_NO = ? GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_INVOICE_NO, 
                P_SELLER_NAME, P_BUYER_NAME, P_POD, P_ORIGIN_COUNTRY, P_ASN_SAVE_DT 
                ORDER BY P_ASN_SAVE_DT ASC ";
    $params[] = $contractNumber;
} 

// Further filtering based on party type (ALL, BUYER, SELLER)
elseif ($partyType === "ALL") {
    $query .= "AND P_ASN_SAVE_DT BETWEEN '$fromDate' AND '$toDate'
     GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_INVOICE_NO, 
                P_SELLER_NAME, P_BUYER_NAME, P_POD, P_ORIGIN_COUNTRY, P_ASN_SAVE_DT 
                ORDER BY P_ASN_SAVE_DT ASC";
} elseif ($partyType === "BUYER") {
    $query .= " AND P_ASN_SAVE_DT BETWEEN '$fromDate' AND '$toDate' AND P_BUYER_NAME = ? 
                GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, 
                P_INVOICE_NO, P_SELLER_NAME, P_BUYER_NAME, P_POD, P_ORIGIN_COUNTRY, 
                P_ASN_SAVE_DT ORDER BY P_ASN_SAVE_DT ASC";
    $params[] = "$partyName"; 
} elseif ($partyType === "SELLER") {
    $query .= " AND P_ASN_SAVE_DT BETWEEN '$fromDate' AND '$toDate'
               AND P_SELLER_NAME = ? GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, 
                P_INVOICE_NO, P_SELLER_NAME, P_BUYER_NAME, P_POD, P_ORIGIN_COUNTRY, 
                P_ASN_SAVE_DT ORDER BY P_ASN_SAVE_DT ASC";
    $params[] = "$partyName"; 
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    $rows = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

    if ($rows) {
        // Display the results in a table format
        echo "<table border='1'>
                <tr>
                    <th>ASN No</th><th>PO No</th><th>Contract No</th><th>Invoice No</th>
                    <th>Seller Name</th><th>Buyer Name</th><th>Port of Discharge</th>
                    <th>Origin Country</th><th>ASN Date</th><th>Net Weight</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            // Convert ASN_DATE to a proper format (if needed)
            $asnDate = $rows['ASN_DATE'] ? $rows['ASN_DATE']->format('Y-m-d') : 'N/A'; // assuming ASN_DATE is a DateTime object

            // Ensure that the SELLER_NAME and BUYER_NAME exist before displaying
            $sellerName = isset($rows['P_SELLER_NAME']) ? htmlspecialchars($rows['P_SELLER_NAME']) : 'N/A';
            $buyerName = isset($rows['P_BUYER_NAME']) ? htmlspecialchars($rows['P_BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($rows['ASN_NO']) . "</td>
                    <td>" . htmlspecialchars($rows['PO_NO']) . "</td>
                    <td>" . htmlspecialchars($rows['CONTRACT_NO']) . "</td>
                    <td>" . htmlspecialchars($rows['INVOICE_NO']) . "</td>
                    <td>" . $sellerName . "</td>  
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($rows['PORT_OF_DISCHARGE']) . "</td>
                    <td>" . htmlspecialchars($rows['ORIGIN_COUNTRY']) . "</td>
                    <td>" . $asnDate . "</td>
                    <td>" . htmlspecialchars($rows['NETWT']) . "</td>
                  </tr>";
        } while ($rows = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));

        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
