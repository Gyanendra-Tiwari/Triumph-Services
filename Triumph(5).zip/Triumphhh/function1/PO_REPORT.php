<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name
$contractButton = isset($_POST['contract_button']) ? $_POST['contract_button'] : ''; // Check if contract_button is set
$contractNumber = isset($_POST['contract_number']) ? $_POST['contract_number'] : ''; // Get contract number

// Debugging: Output received dates and contract number for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";


// Initialize base query with common fields
$query = "SELECT PO_NO, PO_DATE, PO_TYPE, PO_ORDER_TYPE, PO_SELLER_NAME, PO_BUYER_NAME, 
                 PO_COUNTRY_ORIGIN, PO_PAYMENT_TERM AS PAYMENT_TERM, PO_BANK AS PARTY_BANK, PO_USER
          FROM PO_HDR WHERE ISNULL(po_status, 0) <> 9";

// Initialize parameters array
$params = array();

if ($contractButton === 'YES' && !empty($contractNumber)) {
    $query .= " AND Po_sales_CONT_NO = ? ORDER BY PO_DATE";
    $params[] = $contractNumber;  // Binding contract number as a parameter
} elseif ($partyType === "ALL") {
    $query .= " AND PO_DATE BETWEEN ? AND ? ORDER BY PO_DATE";
    $params[] = $fromDate;
    $params[] = $toDate;
} elseif ($partyType === "BUYER") {
    $query .= " AND PO_DATE BETWEEN ? AND ? AND PO_BUYER_NAME = ? ORDER BY PO_DATE";
    $params[] = $fromDate;
    $params[] = $toDate;
    $params[] = $partyName;  // Binding buyer name as a parameter
} elseif ($partyType === "SELLER") {
    $query .= " AND PO_DATE BETWEEN ? AND ? AND PO_SELLER_NAME = ? ORDER BY PO_DATE";
    $params[] = $fromDate;
    $params[] = $toDate;
    $params[] = $partyName;  // Binding seller name as a parameter
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($rows = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        // Display the results in a table format
        echo "<table border='1'>
                <tr>
                    <th>PO No</th><th>PO_DATE</th><th>PO_TYPE</th><th>PO_SELLER_NAME</th>
                    <th>PO_BUYER_NAME</th><th>PO_COUNTRY_ORIGIN</th><th>PAYMENT_TERM</th>
                    <th>PARTY_BANK</th><th>PO_USER</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            // Convert PO_DATE to a proper format (if needed)
            $poDate = $rows['PO_DATE'] ? $rows['PO_DATE']->format('Y-m-d') : 'N/A'; 

            // Ensure that SELLER_NAME and BUYER_NAME exist before displaying
            $sellerName = isset($rows['PO_SELLER_NAME']) ? htmlspecialchars($rows['PO_SELLER_NAME']) : 'N/A';
            $buyerName = isset($rows['PO_BUYER_NAME']) ? htmlspecialchars($rows['PO_BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($rows['PO_NO']) . "</td>
                    <td>" . $poDate . "</td>
                    <td>" . htmlspecialchars($rows['PO_TYPE']) . "</td> 
                    <td>" . $sellerName . "</td>  
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($rows['PO_COUNTRY_ORIGIN']) . "</td>
                    <td>" . htmlspecialchars($rows['PAYMENT_TERM']) . "</td>
                    <td>" . htmlspecialchars($rows['PARTY_BANK']) . "</td>
                    <td>" . htmlspecialchars($rows['PO_USER']) . "</td>
                  </tr>";
        } while ($rows = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));

        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
