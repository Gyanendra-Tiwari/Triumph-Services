<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT P_PONO [PO_NO],PO_DATE,P_GATEPASS [ASN_NO],P_CONTRACT_NO [CONTRACT_NO],PO_CONTRACT_DATE [CONTRACT_DATE],
      P_INVOICE_NO [INVOICE_NO],P_INVOICE_DATE [INVOICE_DATE],P_BUYER_NAME [BUYER_NAME], P_SELLER_NAME [SELLER_NAME],
	  P_CONTAINERNO [CONTAINER_NO], P_ITEM [ITEM], P_RATE [RATE],P_INVOICE_WT [TOTAL_QTY], P_ITEM_QUANTITY [SHIPPED_QTY],
	  P_BUY_COM_RATE [BUYER_COMM_RATE], P_SELLER_COM_RATE [SELELR_COMM_RATE], P_BUY_COM_AMT [BUYER_COMM_AMT],
	  P_SELLER_COM_AMT [SELLER_COMM_AMT] FROM PURCHASE,PO_HDR WHERE P_PONO=PO_NO ";

$params = array(); // Prepare an array to store query parameters

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= "ORDER BY P_GATEPASS ASC";
    $params = array($fromDate, $toDate); // Adding filter for ALL case
} elseif ($partyType === "BUYER") {
    $query .= " AND PO_CONTRACT_DATE BETWEEN ? AND ? AND P_BUYER_NAME = ?
                ORDER BY P_GATEPASS ASC";
    $params = array($fromDate, $toDate, $partyName);
} elseif ($partyType === "SELLER") {
    $query .= " AND PO_CONTRACT_DATE BETWEEN ? AND ? AND P_SELLER_NAME = ?
                ORDER BY P_GATEPASS ASC";
    $params = array($fromDate, $toDate, $partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>PO NO</th><th>PO_DATE</th><th>ASN_NO</th><th>P_CONTRACT_NO</th>
                    <th>CONTRACT_DATE</th><th>INVOICE_NO</th><th>INVOICE_DATE</th>
                    <th>Seller Name</th><th>BUYER NAME</th><th>CONTAINER_NO</th><th>ITEM</th>
                    <th>RATE</th><th>TOTAL_QTY</th><th>SHIPPED_QTY</th><th>BUYER_COMM_RATE</th>
                    <th>SELELR_COMM_RATE</th><th>BUYER_COMM_AMT</th><th>SELLER_COMM_AMT</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            $PO_DATE = $row['PO_DATE'] ? $row['PO_DATE']->format('Y-m-d') : 'N/A';
            $INVOICE_DATE = $row['INVOICE_DATE'] ? $row['INVOICE_DATE']->format('Y-m-d') : 'N/A';
            $CONTRACT_DATE = $row['CONTRACT_DATE'] ? $row['CONTRACT_DATE']->format('Y-m-d') : 'N/A';
            
            $sellerName = isset($row['SELLER_NAME']) ? htmlspecialchars($row['SELLER_NAME']) : 'N/A';
            $buyerName = isset($row['BUYER_NAME']) ? htmlspecialchars($row['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['PO_NO']) . "</td>
                    <td>" . $PO_DATE . "</td>
                    <td>" . htmlspecialchars($row['ASN_NO']) . "</td>
                    <td>" . htmlspecialchars($row['CONTRACT_NO']) . "</td>
                    <td>" . $CONTRACT_DATE . "</td>
                    <td>" . htmlspecialchars($row['INVOICE_NO']) . "</td>
                    <td>" . $INVOICE_DATE . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['CONTAINER_NO']) . "</td>
                    <td>" . htmlspecialchars($row['ITEM']) . "</td>
                    <td>" . htmlspecialchars($row['RATE']) . "</td>
                    <td>" . htmlspecialchars($row['TOTAL_QTY']) . "</td>
                    <td>" . htmlspecialchars($row['SHIPPED_QTY']) . "</td>
                    <td>" . htmlspecialchars($row['BUYER_COMM_RATE']) . "</td>
                    <td>" . htmlspecialchars($row['SELELR_COMM_RATE']) . "</td>
                    <td>" . htmlspecialchars($row['BUYER_COMM_AMT']) . "</td>
                    <td>" . htmlspecialchars($row['SELLER_COMM_AMT']) . "</td>
                  </tr>";

        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));
        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
