<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT P_GATEPASS AS ASN_NO, P_PONO AS PO_NO, P_CONTRACT_NO AS CONTRACT_NO,
                 P_SELLER_NAME AS SELLER_NAME, P_BUYER_NAME AS BUYER_NAME, P_INVOICE_NO AS INVOICE_NO, 
                 SUM(P_ITEM_QUANTITY) AS QTY_SHIPPED, P_DOC_PENDING AS DOCUMENTS_PENDING,
                 DATEDIFF(DAY, P_ASN_SAVE_DT, GETDATE()) AS PENDING_DAYS 
          FROM PURCHASE 
          WHERE P_PO_TYPE = 'UN-PRICED' 
            AND ISNULL(P_PAYMENT_STATUS, 0) = 0 
            AND ISNULL(p_status, 0) <> 9 
          ";

$params = array(); // Prepare an array to store query parameters

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= " GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_BUYER_NAME, P_INVOICE_NO, 
                   P_DOC_PENDING, P_ASN_SAVE_DT";
    $params = array($fromDate, $toDate); // Adding filter for ALL case
} elseif ($partyType === "BUYER") {
    $query .= " AND (P_ASN_SAVE_DT BETWEEN ? AND ?) AND P_BUYER_NAME = ?
    GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_BUYER_NAME, P_INVOICE_NO, 
                   P_DOC_PENDING, P_ASN_SAVE_DT";
    $params = array($fromDate, $toDate, $partyName);
} elseif ($partyType === "SELLER") {
    $query .= " AND (P_ASN_SAVE_DT BETWEEN ? AND ?) AND P_SELLER_NAME = ?
    GROUP BY P_GATEPASS, P_PONO, P_CONTRACT_NO, P_SELLER_NAME, P_BUYER_NAME, P_INVOICE_NO, 
                   P_DOC_PENDING, P_ASN_SAVE_DT";
    $params = array($fromDate, $toDate, $partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>ASN No</th><th>PO No</th><th>CONTRACT_NO</th>
                    <th>Seller Name</th><th>BUYER NAME</th><th>INVOICE_NO</th>
                    <th>QTY_SHIPPED</th><th>DOCUMENTS_PENDING</th><th>PENDING_DAYS</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            $sellerName = isset($row['SELLER_NAME']) ? htmlspecialchars($row['SELLER_NAME']) : 'N/A';
            $buyerName = isset($row['BUYER_NAME']) ? htmlspecialchars($row['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['ASN_NO']) . "</td>
                    <td>" . htmlspecialchars($row['PO_NO']) . "</td>
                    <td>" . htmlspecialchars($row['CONTRACT_NO']) . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['INVOICE_NO']) . "</td>
                    <td>" . htmlspecialchars($row['QTY_SHIPPED']) . "</td>
                    <td>" . htmlspecialchars($row['DOCUMENTS_PENDING']) . "</td>
                    <td>" . htmlspecialchars($row['PENDING_DAYS']) . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));

        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
