<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT PO_NO [PO_NO],PO_DATE,PO_ITEM_DESC [MATERIAL_NAME],PO_BUYER_NAME [BUYER_NAME],
                 PO_SELLER_NAME [SELLER_NAME],PO_QUANTITY [QTY],PO_RATE [RATE] FROM PO_HDR 
                 WHERE isnull(PO_SALES_CONT_NO,'')='' ";

$params = array(); // Prepare an array to store query parameters

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= "";
    
} elseif ($partyType === "BUYER") {
    $query .= " AND PO_BUYER_NAME = ?";
    $params = array($partyName);
} elseif ($partyType === "SELLER") {
    $query .= " AND PO_SELLER_NAME = ?";
    $params = array($partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>PO_NO</th><th>PO_DATE</th><th>MATERIAL_NAME</th>
                    <th>Seller Name</th><th>BUYER NAME</th><th>QTY</th><th>RATE</th>  
                </tr>";

        // Loop through the results and display them in the table
        do {

            $PO_DATE = $row['PO_DATE'] ? $row['PO_DATE']->format('Y-m-d') : 'N/A';
            
            $sellerName = isset($row['SELLER_NAME']) ? htmlspecialchars($row['SELLER_NAME']) : 'N/A';
            $buyerName = isset($row['BUYER_NAME']) ? htmlspecialchars($row['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['PO_NO']) . "</td>
                    <td>" . $PO_DATE . "</td>
                    <td>" . htmlspecialchars($row['MATERIAL_NAME']) . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['QTY']) . "</td>
                    <td>" . htmlspecialchars($row['RATE']) . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));
        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
