<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates and contract number for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";

// Initialize base query with common fields
$query = "SELECT P_GATEPASS AS ASN_NO, P_PONO AS PO_NO, P_NUMBER AS TRANSACTION_NO, P_CONTRACT_NO AS CONTRACT_NO,
                P_INVOICE_NO AS INVOICE_NO, P_SELLER_NAME AS SELLER_NAME, P_BUYER_NAME AS BUYER_NAME, P_ITEM AS MATERIAL_NAME,
                P_ITEM_QUANTITY AS QTY_SHIPPED, P_PO_TYPE AS PO_TYPE, P_BLNO AS BL_NUMBER, P_SHIPPING_LINE AS SHIPPING_LINE, 
                P_CONTAINERNO AS CONTAINER, P_ETA_PORT_DATE AS CNTR_ETA_Port, P_ETA_ICD AS ETA_ICD FROM PURCHASE 
                WHERE P_PO_TYPE='UN-PRICED' AND ISNULL(P_PAYMENT_STATUS, 0) = 0 ";

$params = array(); // Prepare an array to store query parameters

// Further filtering based on party type (ALL, BUYER, SELLER)
if ($partyType === "ALL") {
    $query .= "AND (P_ETA_PORT_DATE BETWEEN ? AND ? OR P_ETA_ICD BETWEEN ? AND ?)";
    $params = array($fromDate, $toDate, $fromDate, $toDate);
} elseif ($partyType === "BUYER") {
    $query .= "AND (P_ETA_PORT_DATE BETWEEN ? AND ? OR P_ETA_ICD BETWEEN ? AND ?) AND P_BUYER_NAME = ?";
    $params = array($fromDate, $toDate, $fromDate, $toDate, $partyName);
} elseif ($partyType === "SELLER") {
    $query .= "AND (P_ETA_PORT_DATE BETWEEN ? AND ? OR P_ETA_ICD BETWEEN ? AND ?) AND P_SELLER_NAME = ?";
    $params = array($fromDate, $toDate, $fromDate, $toDate, $partyName);
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<table border='1'>
                <tr>
                    <th>ASN No</th><th>PO No</th><th>TRANSACTION_NO</th><th>CONTRACT_NO</th>
                    <th>INVOICE_NO</th><th>Seller Name</th><th>Buyer Name</th><th>MATERIAL_NAME</th>
                    <th>QTY_SHIPPED</th><th>PO_TYPE</th><th>BL_NUMBER</th><th>SHIPPING_LINE</th>
                    <th>CONTAINER</th><th>CNTR_ETA_Port</th><th>ETA_ICD</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            $CNTR_ETA_Port = $row['CNTR_ETA_Port'] ? $row['CNTR_ETA_Port']->format('Y-m-d') : 'N/A';
            $ETA_ICD = $row['ETA_ICD'] ? $row['ETA_ICD']->format('Y-m-d') : 'N/A';

            $sellerName = isset($row['SELLER_NAME']) ? htmlspecialchars($row['SELLER_NAME']) : 'N/A';
            $buyerName = isset($row['BUYER_NAME']) ? htmlspecialchars($row['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($row['ASN_NO']) . "</td>
                    <td>" . htmlspecialchars($row['PO_NO']) . "</td>
                    <td>" . htmlspecialchars($row['TRANSACTION_NO']) . "</td>
                    <td>" . htmlspecialchars($row['CONTRACT_NO']) . "</td>
                    <td>" . htmlspecialchars($row['INVOICE_NO']) . "</td>
                    <td>" . $sellerName . "</td>
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($row['MATERIAL_NAME']) . "</td>
                    <td>" . htmlspecialchars($row['QTY_SHIPPED']) . "</td>
                    <td>" . htmlspecialchars($row['PO_TYPE']) . "</td>
                    <td>" . htmlspecialchars($row['BL_NUMBER']) . "</td>
                    <td>" . htmlspecialchars($row['SHIPPING_LINE']) . "</td>
                    <td>" . htmlspecialchars($row['CONTAINER']) . "</td>
                    <td>" . $CNTR_ETA_Port . "</td>
                    <td>" . $ETA_ICD . "</td>
                  </tr>";
        } while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));

        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
