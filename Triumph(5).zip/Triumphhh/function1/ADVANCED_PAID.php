<?php
// Include your database connection
include("../include/connection.php");

// Collecting form data sent via POST
$partyType = $_POST['party_type'];
$fromDate = $_POST['from_date'];
$toDate = $_POST['to_date'];
$partyName = $_POST['party_name']; // Buyer or Seller name

// Debugging: Output received dates and contract number for validation
echo "Received From Date: $fromDate <br>";
echo "Received To Date: $toDate <br>";


// Initialize base query with common fields
$query = "SELECT PO_NO[PO_NO],PO_SALES_CONT_NO [SALES_CONTRACT_NO],PO_CONTRACT_DATE [CONTRACT_DATE],
           PO_SELLER_NAME [SELLER_NAME],PO_BUYER_NAME [BUYER_NAME],PO_ITEM_DESC [MATERIAL],
		   PO_RATE [RATE], PO_QUANTITY [QTY],PO_ADV_PAID_AMT [ADVANCE RECEIVED],
		   PO_ADV_PAID_DATE [PAID_DATE] from PO_HDR WHERE PO_ADVANCE_FLAG=2";

// Initialize parameters array
$params = array();


if ($partyType === "ALL") {
    $query .= "";
    $params[] = $fromDate;
    $params[] = $toDate;
} elseif ($partyType === "BUYER") {
    $query .= " AND OIL_DATE BETWEEN ? AND ? AND PO_BUYER_NAME = ? ";
    $params[] = $fromDate;
    $params[] = $toDate;
    $params[] = $partyName;  // Binding buyer name as a parameter
} elseif ($partyType === "SELLER") {
    $query .= " AND OIL_DATE BETWEEN ? AND ? AND PO_SELLER_NAME = ? ";
    $params[] = $fromDate;
    $params[] = $toDate;
    $params[] = $partyName;  // Binding seller name as a parameter
}

// Prepare the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

// Check if the query execution was successful and fetch results
if ($result) {
    // Check if there are rows returned
    if ($rows = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        // Display the results in a table format
        echo "<table border='1'>
                <tr>
                    <th>PO No</th><th>SALES_CONTRACT_NO</th><th>CONTRACT_DATE</th><th>PO_SELLER_NAME</th>
                    <th>PO_BUYER_NAME</th><th>MATERIAL</th><th>RATE</th>
                    <th>QTY</th><th>ADVANCE RECEIVED</th>
                </tr>";

        // Loop through the results and display them in the table
        do {
            // Convert PO_DATE to a proper format (if needed)
            $CONTRACT_DATE = $rows['CONTRACT_DATE'] ? $rows['CONTRACT_DATE']->format('Y-m-d') : 'N/A'; 

            // Ensure that SELLER_NAME and BUYER_NAME exist before displaying
            $sellerName = isset($rows['SELLER_NAME']) ? htmlspecialchars($rows['SELLER_NAME']) : 'N/A';
            $buyerName = isset($rows['BUYER_NAME']) ? htmlspecialchars($rows['BUYER_NAME']) : 'N/A';

            echo "<tr>
                    <td>" . htmlspecialchars($rows['PO_NO']) . "</td>
                    <td>" . htmlspecialchars($rows['SALES_CONTRACT_NO']) . "</td>
                    <td>" . $CONTRACT_DATE . "</td>
                    <td>" . $sellerName . "</td>  
                    <td>" . $buyerName . "</td>
                    <td>" . htmlspecialchars($rows['MATERIAL']) . "</td>
                    <td>" . htmlspecialchars($rows['RATE']) . "</td>
                    <td>" . htmlspecialchars($rows['QTY']) . "</td>
                    <td>" . htmlspecialchars($rows['ADVANCE RECEIVED']) . "</td>
                  </tr>";
        } while ($rows = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC));
      
        echo "</table>";
    } else {
        echo "No data found for the given filters.";
    }
} else {
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Free statement and close the connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
