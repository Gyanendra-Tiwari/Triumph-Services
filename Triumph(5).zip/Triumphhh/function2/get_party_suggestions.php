<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection
include("../include/connection.php");

$partyName = strtoupper($_GET['name']); // Get the name to search for

// Log the data received (optional, for debugging)
error_log("Received Party Name: " . $partyName);

// Query for BUYER
$query = "SELECT party_name FROM Party_Master WHERE UPPER(party_name) LIKE ? ORDER BY party_name";
$params = array("%" . $partyName . "%");

$stmt = sqlsrv_prepare($conn, $query, $params);

if (!$stmt) {
    // Log error if query preparation fails
    error_log("Error in preparing statement: " . print_r(sqlsrv_errors(), true));
    echo json_encode(["error" => "Error preparing SQL query"]);
    exit;
}

if (sqlsrv_execute($stmt)) {
    $suggestions = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $suggestions[] = $row['party_name'];
    }

    // Log the suggestions (optional, for debugging)
    error_log("Suggestions: " . json_encode($suggestions));

    // Set the correct content type for JSON
    header('Content-Type: application/json');
    
    // Return the suggestions as JSON
    echo json_encode($suggestions);
} else {
    // If the query execution fails, return an error
    echo json_encode(["error" => "Error executing SQL query"]);
}

// Clean up
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
