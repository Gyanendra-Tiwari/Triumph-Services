<?php
// Database connection
header('Content-Type: application/json');

include("../include/connection.php");

// Get the party name from the query string and convert it to uppercase
$partyName = strtoupper($_GET['name']);

// Query to search for sellers whose name matches the provided party name
$query = "SELECT seller_name FROM Seller_Master WHERE UPPER(seller_name) LIKE ? ORDER BY seller_name";
$params = array("%" . $partyName . "%");

// Prepare and execute the query
$stmt = sqlsrv_prepare($conn, $query, $params);

if (sqlsrv_execute($stmt)) {
    // Initialize an empty array to store seller suggestions
    $suggestions = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $suggestions[] = $row['seller_name']; // Collect seller names into the array
    }
    
    // Return the suggestions as JSON
    echo json_encode($suggestions);
} else {
    // Return an empty array in case of error
    echo json_encode([]);
}

// Free the statement and close the database connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>
