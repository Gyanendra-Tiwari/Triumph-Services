<?php
// Connection parameters
$serverName = "PIPL-002\SQLEXPRESS";  // Your SQL Server instance
$username = "sa";               // Your SQL Server username
$password = "1234";             // Your SQL Server password
$dbname = "TRIUMPH";            // Your database name

// Connection info
$connectionInfo = array(
    "UID" => $username,
    "PWD" => $password,
    "Database" => $dbname
);

// Attempt to connect to SQL Server
$conn = sqlsrv_connect($serverName, $connectionInfo);

// Check if the connection is successful
if (!$conn) {
    // Connection failed, retrieve and display the error message
    $errors = sqlsrv_errors();
    $response = array(
        'message' => isset($errors[0]['message']) ? $errors[0]['message'] : 'Unknown error',
        'status' => false
    );
    echo json_encode($response);
    return null;  // Return null to indicate the failure
}
echo("");
// Connection successful
return $conn;
?>
